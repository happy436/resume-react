import React from 'react'
import v from "../../styles/shared.module.scss"

export const Portfolio = () => {
    return (
        <div className={v.section}>Comming soon</div>
        /* <section className="project section">
            <div className="project__bg">
                <div className="project__container container grid">
                    <div className="project__data">
                        <h2 className="project__title">Хочешь записатся на тренировку?</h2>
                        <p className="project__description">Свяжись со мной или приходи в зал.</p>
                        <a href="#contact" className="button button--flex button--white">
                            Контакты
                            <i className="uil uil-message project__icon button__icon"></i>
                        </a>
                    </div>
                    <img src="./img/project-light.png" alt="project-img" className="project__img" />
                </div>
            </div>
        </section> */
    )
}
