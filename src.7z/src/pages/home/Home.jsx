import React from 'react'
import s from "./Home.module.scss"
import v from "../../styles/shared.module.scss"
import { UilInstagram, UilFacebookF, UilTelegramAlt, UilGithubAlt, UilMessage } from '@iconscout/react-unicons'
import { NavLink } from 'react-router-dom'

export const Home = (props) => {
    return (
        <section className={`${v.section}`} id="home">
            <div className={`${s.home__container} ${v.container} ${v.grid}`}>
                <div className={`${s.home__content} ${v.grid}`}>
                    <div className={s.home__social}>
                        <a href="https://www.instagram.com/lelouch436/" rel="noreferrer" target="_blank" className={s.home__social_icon}>
                            <UilInstagram/>
                        </a>
                        <a href="https://www.facebook.com/profile.php?id=100006441279823" rel="noreferrer" target="_blank" className={s.home__social_icon}>
                            <UilFacebookF/>
                        </a>
                        <a href="https://t.me/happy436" rel="noreferrer" target="_blank" className={s.home__social_icon}>
                            <UilTelegramAlt/>
                        </a>
                        <a href="https://github.com/happy436?tab=repositories" rel="noreferrer" target="_blank" className={s.home__social_icon}>
                            <UilGithubAlt/>
                        </a>
                    </div>
                    <div className={s.home__img}>
                        <svg className={s.home__blob} viewBox="0 0 200 187" >
                            <mask id="mask0" mask-type="alpha">
                                <path d="M190.312 36.4879C206.582 62.1187 201.309 102.826 182.328 134.186C163.346 165.547 
                                130.807 187.559 100.226 186.353C69.6454 185.297 41.0228 161.023 21.7403 129.362C2.45775 
                                97.8511 -7.48481 59.1033 6.67581 34.5279C20.9871 10.1032 59.7028 -0.149132 97.9666 
                                0.00163737C136.23 0.303176 174.193 10.857 190.312 36.4879Z"/>
                            </mask>
                            <g mask="url(#mask0)">
                                <path d="M190.312 36.4879C206.582 62.1187 201.309 102.826 182.328 134.186C163.346 
                                165.547 130.807 187.559 100.226 186.353C69.6454 185.297 41.0228 161.023 21.7403 
                                129.362C2.45775 97.8511 -7.48481 59.1033 6.67581 34.5279C20.9871 10.1032 59.7028 
                                -0.149132 97.9666 0.00163737C136.23 0.303176 174.193 10.857 190.312 36.4879Z"/>
                                <image className={s.home__blob_img} 
                                alt="ava" 
                                y="-50"
                                xlinkHref="https://scontent.fiev19-1.fna.fbcdn.net/v/t31.18172-8/14500285_2106932076198148_3144363199451259631_o.jpg?_nc_cat=104&ccb=1-5&_nc_sid=09cbfe&_nc_ohc=9aaPXXuJSqoAX8kN3wP&_nc_ht=scontent.fiev19-1.fna&oh=00_AT9vBq8pmGkMHsKmW-21C9AHFwcQFWLk82fTfXjj437qsA&oe=61FC3CED"/>
                            </g>
                        </svg>
                    </div>
                    <div className={s.home__data}>
                        <h1 className={s.home__title}>Привет, я Олег</h1>
                        <h3 className={s.home__subtitle}>Front-end developer</h3>
                        <p className={s.home__description}>Опыт работы 01+ год</p>
                        <NavLink to={`${props.baseURL}/contact-me`} className={`${v.button} ${v.button__flex}`}>
                            Контакты<UilMessage className={v.button__icon}/>
                        </NavLink>
                    </div>
                </div>
            </div>
        </section>
    )
}
